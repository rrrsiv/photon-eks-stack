import _ from 'lodash';

export class CompareQueriesConfigCtrl {
  static templateUrl = 'partials/config.html';
  current: any;
}
