# Changelog

## 0.0.2

- Converts from Grunt to Grafana toolkit and converts the remaining JavaScript files to TypeScript. Using Yarn for npm packages.
- Fixes dataframe timeshift processing.
